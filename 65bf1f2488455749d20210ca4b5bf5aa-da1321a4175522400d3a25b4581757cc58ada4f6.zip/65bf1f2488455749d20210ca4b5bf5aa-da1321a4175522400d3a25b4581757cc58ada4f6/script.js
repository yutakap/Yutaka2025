const canvas = document.getElementById("board");
const ctx = canvas.getContext("2d");
const info = document.getElementById("info");
const passBtn = document.getElementById("passBtn");
const resetBtn = document.getElementById("resetBtn");

const SIZE = 8;
const CELL_SIZE = canvas.width / SIZE;

const BLACK = "black";
const WHITE = "white";
const EMPTY = null;

// 盤面配列
let board = [];
let currentTurn = BLACK;
let consecutivePasses = 0; // 連続パスカウント

// 方向ベクトル（上下左右と斜め8方向）
const directions = [
  [-1, -1], [-1, 0], [-1, 1],
  [0, -1],          [0, 1],
  [1, -1],  [1, 0], [1, 1],
];

// 初期化
function initBoard() {
  board = Array.from({ length: SIZE }, () => Array(SIZE).fill(EMPTY));

  // 初期4石配置（Wikipedia準拠）
  // 盤中央4マス
  // 左上(3,3)：白
  // 右下(4,4)：白
  // 右上(3,4)：黒
  // 左下(4,3)：黒
  board[3][3] = WHITE;
  board[4][4] = WHITE;
  board[3][4] = BLACK;
  board[4][3] = BLACK;

  currentTurn = BLACK;
  consecutivePasses = 0;
  updateInfo();
  drawBoard();
}

// 描画関数
function drawBoard() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  // 盤面背景とマス目
  for (let r = 0; r < SIZE; r++) {
    for (let c = 0; c < SIZE; c++) {
      ctx.fillStyle = "#0a662f";
      ctx.fillRect(c * CELL_SIZE, r * CELL_SIZE, CELL_SIZE, CELL_SIZE);
      ctx.strokeStyle = "#004517";
      ctx.strokeRect(c * CELL_SIZE, r * CELL_SIZE, CELL_SIZE, CELL_SIZE);

      if (board[r][c] !== EMPTY) {
        drawStone(c, r, board[r][c]);
      }
    }
  }
}

// 石を描画する
function drawStone(col, row, color) {
  const cx = col * CELL_SIZE + CELL_SIZE / 2;
  const cy = row * CELL_SIZE + CELL_SIZE / 2;
  const radius = CELL_SIZE * 0.4;

  ctx.beginPath();
  ctx.arc(cx, cy, radius, 0, 2 * Math.PI);
  ctx.fillStyle = color;
  ctx.fill();

  if (color === WHITE) {
    ctx.strokeStyle = "black";
    ctx.lineWidth = 2;
    ctx.stroke();
  }
}

// 盤面内か判定
function inBounds(r, c) {
  return r >= 0 && r < SIZE && c >= 0 && c < SIZE;
}

// 指定位置に石を置けるか（合法手判定）
// 挟める石が1つでもあればtrue
function canPlaceStone(r, c, color) {
  if (board[r][c] !== EMPTY) return false;

  const opponent = (color === BLACK) ? WHITE : BLACK;

  // 全方向チェック
  for (const [dr, dc] of directions) {
    let nr = r + dr;
    let nc = c + dc;
    let foundOpponent = false;

    while (inBounds(nr, nc) && board[nr][nc] === opponent) {
      nr += dr;
      nc += dc;
      foundOpponent = true;
    }

    if (
      foundOpponent &&
      inBounds(nr, nc) &&
      board[nr][nc] === color
    ) {
      return true;
    }
  }
  return false;
}

// 指定の色が合法手を1つでも持つか判定
function hasAnyValidMove(color) {
  for (let r = 0; r < SIZE; r++) {
    for (let c = 0; c < SIZE; c++) {
      if (canPlaceStone(r, c, color)) return true;
    }
  }
  return false;
}

// 指定マスに石を置き、挟まれた石を反転させる（合法手前提）
function placeStone(r, c, color) {
  board[r][c] = color;
  const opponent = (color === BLACK) ? WHITE : BLACK;

  for (const [dr, dc] of directions) {
    let stonesToFlip = [];
    let nr = r + dr;
    let nc = c + dc;

    while (inBounds(nr, nc) && board[nr][nc] === opponent) {
      stonesToFlip.push([nr, nc]);
      nr += dr;
      nc += dc;
    }

    if (
      stonesToFlip.length > 0 &&
      inBounds(nr, nc) &&
      board[nr][nc] === color
    ) {
      // 挟んだ石を裏返す
      for (const [fr, fc] of stonesToFlip) {
        board[fr][fc] = color;
      }
    }
  }
}

// 盤面が全て埋まったか判定
function isBoardFull() {
  for (let r = 0; r < SIZE; r++) {
    for (let c = 0; c < SIZE; c++) {
      if (board[r][c] === EMPTY) return false;
    }
  }
  return true;
}

// 石の数を数える
function countStones() {
  let blackCount = 0;
  let whiteCount = 0;
  for (let r = 0; r < SIZE; r++) {
    for (let c = 0; c < SIZE; c++) {
      if (board[r][c] === BLACK) blackCount++;
      else if (board[r][c] === WHITE) whiteCount++;
    }
  }
  return { blackCount, whiteCount };
}

// 情報表示更新
function updateInfo() {
  const { blackCount, whiteCount } = countStones();
  let turnText = currentTurn === BLACK ? "黒のターン" : "白のターン";
  info.textContent = `${turnText} | 黒: ${blackCount} 石 - 白: ${whiteCount} 石`;
}

// ゲーム終了処理
function gameOver() {
  const { blackCount, whiteCount } = countStones();
  let winnerText = "引き分けです。";
  if (blackCount > whiteCount) winnerText = "黒の勝ちです！";
  else if (whiteCount > blackCount) winnerText = "白の勝ちです！";

  info.textContent = `ゲーム終了！ ${winnerText} 黒: ${blackCount} - 白: ${whiteCount}`;
  passBtn.disabled = true;
  canvas.removeEventListener("click", onClickBoard);
}

// クリックイベント処理
function onClickBoard(e) {
  const rect = canvas.getBoundingClientRect();
  const x = e.clientX - rect.left;
  const y = e.clientY - rect.top;
  const col = Math.floor(x / CELL_SIZE);
  const row = Math.floor(y / CELL_SIZE);

  if (!inBounds(row, col)) return;

  if (canPlaceStone(row, col, currentTurn)) {
    placeStone(row, col, currentTurn);
    consecutivePasses = 0;
    // ターン交代
    currentTurn = (currentTurn === BLACK) ? WHITE : BLACK;

    drawBoard();

    // 次のプレイヤーが合法手を持つか判定
    if (!hasAnyValidMove(currentTurn)) {
      consecutivePasses++;
      if (consecutivePasses >= 2 || isBoardFull()) {
        // 両者パスか盤面埋まったら終了
        gameOver();
        return;
      } else {
        // パスを通知しターン戻す
        alert(`${currentTurn === BLACK ? "黒" : "白"}は合法手なしのためパスします。`);
        currentTurn = (currentTurn === BLACK) ? WHITE : BLACK;
      }
    } else {
      consecutivePasses = 0;
    }

    updateInfo();

  } else {
    alert("その場所には置けません。挟める石がある場所を選んでください。");
  }
}

// パスボタン処理
function onPass() {
  if (!hasAnyValidMove(currentTurn)) {
    consecutivePasses++;
    if (consecutivePasses >= 2 || isBoardFull()) {
      gameOver();
      return;
    }
    currentTurn = (currentTurn === BLACK) ? WHITE : BLACK;
    alert(`${currentTurn === BLACK ? "黒" : "白"}のターンです。`);
    updateInfo();
  } else {
    alert("合法手があるためパスはできません。");
  }
}

// リセットボタン処理
function onReset() {
  initBoard();
  passBtn.disabled = false;
  canvas.addEventListener("click", onClickBoard);
}

// 初期化＆イベント登録
initBoard();
canvas.addEventListener("click", onClickBoard);
passBtn.addEventListener("click", onPass);
resetBtn.addEventListener("click", onReset);
